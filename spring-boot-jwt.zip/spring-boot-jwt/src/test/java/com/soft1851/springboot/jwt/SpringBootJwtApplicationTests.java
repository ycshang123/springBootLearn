package com.soft1851.springboot.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJwtApplicationTests {

    @Test
    void contextLoads() {
    }

}
