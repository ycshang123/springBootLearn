package com.soft1851.springboot.jwt.test;/*@ClassName Decrypt
 *@Description:todo
 *@author yc_shang
 *@Date2020/4/15
 *@Version 1.0
 **/

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.io.UnsupportedEncodingException;


public class Decrypt {
    /**
     * 先验证token是否被改造，然后解码token
     * @param token
     * @return
     */
    public DecodedJWT deToken(final String token){
        DecodedJWT jwt = null;
        try {
            //使用了HMAC256加密算法，mySecret是用来加密数字签名的密钥
            JWTVerifier verifier = JWT.require(Algorithm.HMAC256("4d91a4dbca0a5f2f"))
                    .withIssuer("auth0")
                    .build();
            jwt = verifier.verify(token);
        }catch (JWTVerificationException | IllegalArgumentException | UnsupportedEncodingException e){
            e.printStackTrace();
        }
        return  jwt;
    }
}
