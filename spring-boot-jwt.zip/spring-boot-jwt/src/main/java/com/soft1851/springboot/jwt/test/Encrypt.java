package com.soft1851.springboot.jwt.test;/*@ClassName Encrypt
 *@Description:todo
 *@author yc_shang
 *@Date2020/4/15
 *@Version 1.0
 **/

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.soft1851.springboot.jwt.util.Md5Util;

import java.sql.Date;

public class Encrypt {
    /**
     *
     * @param isVip
     * @param username
     * @param name
     * @return token
     * 返回加密的token
     */
   public String getToken(final boolean isVip, final String username,final  String name){
       String token = null;
       String secret = Md5Util.getMD5("bhg852",16);
       try {
           Date expiresAt = new Date(System.currentTimeMillis() + 50L*1000L);
           token = JWT.create()
                   .withIssuer("auth0")
                   .withClaim("isVip",isVip)
                   .withClaim("username",username)
                   .withClaim("name",name)
                   .withExpiresAt(expiresAt)
                   .sign(Algorithm.HMAC256(secret));

       }catch (Exception e){
           e.printStackTrace();
       }
       return  token;
   }

    public static void main(String[] args) {

        String secret = Md5Util.getMD5("bhg852",16);
        System.out.println(secret);
    }
}
