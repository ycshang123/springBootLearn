package com.soft1851.springboot.jwt.test;/*@ClassName Test
 *@Description:todo
 *@author yc_shang
 *@Date2020/4/15
 *@Version 1.0
 **/

import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.Date;

public class Test {

    public static void main(String[] args) {
        //生成token
        Encrypt encrypt = new Encrypt();
        String token = encrypt.getToken(true,"syc123","syc123");
        //打印token
        System.out.println("token: " + token);



        //揭秘token
        Decrypt decrypt = new Decrypt();
        DecodedJWT jwt = decrypt.deToken(token);

        Date date = new Date(System.currentTimeMillis());
        String status;
        if(jwt.getExpiresAt().before(date)){
            status ="到了";
        }else {
            status ="没到";
        }

        System.out.println("issuer:"+ jwt.getIssuer());
        System.out.println("isVip:" + jwt.getClaim("isVip").asBoolean());
        System.out.println("username:" + jwt.getClaim("username").asString());
        System.out.println("name:" + jwt.getClaim("name").asString());
        System.out.println("过期时间" + jwt.getExpiresAt());
        System.out.println("过期时间是否已经到了:" + status);

    }

}
