package com.soft1851.springboot.jwt.exception;/*@ClassName JwtException
 *@Description:todo
 *@author yc_shang
 *@Date2020/4/15
 *@Version 1.0
 **/

import com.soft1851.springboot.jwt.common.ResultCode;

public class JwtException extends  RuntimeException {
    public ResultCode resultCode;
    public JwtException(String msg,ResultCode resultCode){
        super(msg);
        this.resultCode = resultCode;
    }
    public  ResultCode getResultCode(){
        return  resultCode;
    }
}
